<x-anggota-layout activeMenu="simpanan" headerTitle="Simpanan — Dashboard Anggota">

    <div style="display:flex; gap:20px; margin-bottom:24px;">
        <div style="flex:1; background:#FDEEEE; border-radius:6px; padding:16px; text-align:center;">
            <p style="margin:0 0 6px; color:#7F1D1D; font-size:13px;">Saldo Simpanan Wajib</p>
            <p style="margin:0; color:#241412; font-size:22px; font-weight:bold;">Rp {{ number_format($saldoWajib, 0, ',', '.') }}</p>
        </div>
        <div style="flex:1; background:#FDEEEE; border-radius:6px; padding:16px; text-align:center;">
            <p style="margin:0 0 6px; color:#7F1D1D; font-size:13px;">Saldo Simpanan Sukarela</p>
            <p style="margin:0; color:#241412; font-size:22px; font-weight:bold;">Rp {{ number_format($saldoSukarela, 0, ',', '.') }}</p>
        </div>
    </div>

    {{-- Tab --}}
    <div style="display:flex; gap:8px; margin-bottom:20px;">
        <a href="{{ route('simpanan.setor') }}" style="padding:10px 20px; border:1px solid #B91C1C; border-radius:4px; text-decoration:none; color:#ffffff; font-weight:bold; background:#B91C1C;">Setoran</a>
        <a href="{{ route('simpanan.tarik') }}" style="padding:10px 20px; border:1px solid #F3B4B4; border-radius:4px; text-decoration:none; color:#B91C1C; font-weight:bold; background:#ffffff;">Penarikan</a>
        <a href="{{ route('simpanan.riwayat') }}" style="padding:10px 20px; border:1px solid #F3B4B4; border-radius:4px; text-decoration:none; color:#B91C1C; font-weight:bold; background:#ffffff;">Riwayat</a>
    </div>

    <h3 style="font-size:16px; font-weight:bold; color:#241412; margin:0 0 16px;">Form Setoran Simpanan</h3>

    @if ($errors->any())
        <div style="background:#FDEEEE; color:#B91C1C; border:1px solid #F3B4B4; border-radius:4px; padding:12px 16px; margin-bottom:16px; font-size:14px;">
            @foreach ($errors->all() as $error)
                <p style="margin:2px 0;">{{ $error }}</p>
            @endforeach
        </div>
    @endif

    <form method="POST" action="{{ route('simpanan.setor.store') }}" enctype="multipart/form-data" style="max-width:500px;" id="formSetor">
        @csrf

        <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">Jenis Simpanan</label>
        <select name="jenis_simpanan" id="jenis_simpanan" required
                style="width:100%; padding:10px 12px; border:1px solid #F3B4B4; border-radius:4px; margin-bottom:4px; font-family:Arial, sans-serif;">
            <option value="">-- Pilih --</option>
            <option value="Wajib" {{ old('jenis_simpanan') == 'Wajib' ? 'selected' : '' }}>Wajib</option>
            <option value="Sukarela" {{ old('jenis_simpanan') == 'Sukarela' ? 'selected' : '' }}>Sukarela</option>
        </select>
        <p style="font-size:12px; color:#9CA3AF; margin:0 0 16px;">Min. wajib: Rp 50.000 &nbsp;|&nbsp; Min. sukarela: Rp 10.000</p>

        <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">Jumlah Setoran (Rp)</label>
        <input type="text" inputmode="numeric" id="jumlah_display" placeholder="Rp 0" required
       value="{{ old('jumlah') ? 'Rp ' . number_format(old('jumlah'), 0, ',', '.') : '' }}"
       style="width:100%; padding:10px 12px; border:1px solid #F3B4B4; border-radius:4px; margin-bottom:4px; box-sizing:border-box; font-family:Arial, sans-serif;">
<input type="hidden" name="jumlah" id="jumlah">
<p id="jumlah_error" style="display:none; color:#B91C1C; font-size:12px; margin:0 0 16px;"></p>

        <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">Metode Setoran</label>
        <select name="metode_setoran" id="metode_setoran" required
                style="width:100%; padding:10px 12px; border:1px solid #F3B4B4; border-radius:4px; margin-bottom:16px; font-family:Arial, sans-serif;">
            <option value="">-- Pilih --</option>
            <option value="QRIS" {{ old('metode_setoran') == 'QRIS' ? 'selected' : '' }}>QRIS</option>
            <option value="Tunai" {{ old('metode_setoran') == 'Tunai' ? 'selected' : '' }}>Tunai</option>
        </select>

        <div id="uploadArea" style="display:none; margin-bottom:20px;">
            <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">Upload Bukti QRIS</label>
            <input type="file" name="bukti_qris" accept="image/*"
                   style="width:100%; padding:10px 12px; border:1px dashed #B0B0B0; border-radius:4px; background:#F4F4F4; box-sizing:border-box;">
        </div>

        <div style="display:flex; gap:8px;">
            <button type="submit" style="padding:12px 28px; background:#B91C1C; color:#ffffff; border:none; border-radius:4px; font-weight:bold; cursor:pointer;">Kirim</button>
            <a href="{{ route('simpanan.setor') }}" style="padding:12px 28px; background:#ffffff; color:#241412; border:1px solid #F3B4B4; border-radius:4px; font-weight:bold; text-decoration:none;">Batal</a>
        </div>
    </form>

    <script>
        const metodeSelect = document.getElementById('metode_setoran');
        const uploadArea = document.getElementById('uploadArea');
        function toggleUpload() {
        const jumlahDisplay = document.getElementById('jumlah_display');
        const jumlahHidden = document.getElementById('jumlah');

        function formatRibuan(v) {
            return v.replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        }

        jumlahDisplay.addEventListener('input', function () {
            const angka = this.value.replace(/\D/g, '');
            this.value = angka ? 'Rp ' + formatRibuan(angka) : '';
            jumlahHidden.value = angka;
        });

        document.getElementById('formSetor').addEventListener('submit', function () {
            jumlahHidden.value = jumlahDisplay.value.replace(/\D/g, '');
        });
            uploadArea.style.display = metodeSelect.value === 'QRIS' ? 'block' : 'none';
        }
        metodeSelect.addEventListener('change', toggleUpload);
        toggleUpload();
    </script>

</x-anggota-layout>
