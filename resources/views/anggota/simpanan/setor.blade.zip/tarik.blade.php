<x-anggota-layout activeMenu="simpanan" headerTitle="Simpanan — Dashboard Anggota">

    <div style="display:flex; gap:20px; margin-bottom:24px;">
        <div style="flex:1; background:#FDEEEE; border-radius:6px; padding:16px; text-align:center;">
            <p style="margin:0 0 6px; color:#7F1D1D; font-size:13px;">Saldo Simpanan Wajib</p>
            <p style="margin:0; color:#241412; font-size:22px; font-weight:bold;">Rp {{ number_format($saldoWajib, 0, ',', '.') }}</p>
        </div>
        <div style="flex:1; background:#FDEEEE; border-radius:6px; padding:16px; text-align:center;">
            <p style="margin:0 0 6px; color:#7F1D1D; font-size:13px;">Saldo Simpanan Sukarela (bisa ditarik)</p>
            <p style="margin:0; color:#241412; font-size:22px; font-weight:bold;">Rp {{ number_format($saldoSukarela, 0, ',', '.') }}</p>
        </div>
    </div>

    {{-- Tab --}}
    <div style="display:flex; gap:8px; margin-bottom:20px;">
        <a href="{{ route('simpanan.setor') }}" style="padding:10px 20px; border:1px solid #F3B4B4; border-radius:4px; text-decoration:none; color:#B91C1C; font-weight:bold; background:#ffffff;">Setoran</a>
        <a href="{{ route('simpanan.tarik') }}" style="padding:10px 20px; border:1px solid #B91C1C; border-radius:4px; text-decoration:none; color:#ffffff; font-weight:bold; background:#B91C1C;">Penarikan</a>
        <a href="{{ route('simpanan.riwayat') }}" style="padding:10px 20px; border:1px solid #F3B4B4; border-radius:4px; text-decoration:none; color:#B91C1C; font-weight:bold; background:#ffffff;">Riwayat</a>
    </div>

    <h3 style="font-size:16px; font-weight:bold; color:#241412; margin:0 0 16px;">Form Penarikan Simpanan Sukarela</h3>

    @if ($errors->any())
        <div style="background:#FDEEEE; color:#B91C1C; border:1px solid #F3B4B4; border-radius:4px; padding:12px 16px; margin-bottom:16px; font-size:14px;">
            @foreach ($errors->all() as $error)
                <p style="margin:2px 0;">{{ $error }}</p>
            @endforeach
        </div>
    @endif

    <form method="POST" action="{{ route('simpanan.tarik.store') }}" style="max-width:500px;" id="formTarik">
        @csrf

        <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">Jumlah Penarikan (Rp)</label>
<input type="text" inputmode="numeric" id="jumlah_display" placeholder="Rp 0" required
       value="{{ old('jumlah') ? 'Rp ' . number_format(old('jumlah'), 0, ',', '.') : '' }}"
       style="width:100%; padding:10px 12px; border:1px solid #F3B4B4; border-radius:4px; box-sizing:border-box; font-family:Arial, sans-serif;">
<input type="hidden" name="jumlah" id="jumlah">
<p id="jumlah_error" style="display:none; color:#B91C1C; font-size:12px; margin:4px 0 0;"></p>
        <p style="font-size:12px; color:#9CA3AF; margin:4px 0 16px;">Minimal: Rp 50.000 sesuai ketentuan koperasi. Maks: Rp {{ number_format($saldoSukarela, 0, ',', '.') }}</p>

        <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">Metode Penarikan</label>
        <select name="metode_penarikan" id="metode_penarikan" required
                style="width:100%; padding:10px 12px; border:1px solid #F3B4B4; border-radius:4px; margin-bottom:16px; font-family:Arial, sans-serif;">
            <option value="">-- Pilih --</option>
            <option value="Transfer Bank" {{ old('metode_penarikan') == 'Transfer Bank' ? 'selected' : '' }}>Transfer Bank</option>
            <option value="Tunai" {{ old('metode_penarikan') == 'Tunai' ? 'selected' : '' }}>Tunai</option>
        </select>

        <div id="rekeningArea">
            <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">Nama Bank / E-Wallet</label>
            <input type="text" name="nama_bank_ewallet" value="{{ old('nama_bank_ewallet') }}" placeholder="cth: BCA, Dana, dsb (kosongkan jika Tunai)"
                   style="width:100%; padding:10px 12px; border:1px solid #F3B4B4; border-radius:4px; margin-bottom:16px; box-sizing:border-box; font-family:Arial, sans-serif;">

            <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">No. Rekening / No. HP Tujuan</label>
            <input type="text" name="no_rekening_tujuan" value="{{ old('no_rekening_tujuan') }}" placeholder="kosongkan jika pilih Tunai"
                   style="width:100%; padding:10px 12px; border:1px solid #F3B4B4; border-radius:4px; margin-bottom:16px; box-sizing:border-box; font-family:Arial, sans-serif;">
        </div>

        <label style="display:block; font-size:14px; color:#241412; margin-bottom:6px;">Nama Pemilik Rekening</label>
        <input type="text" name="nama_pemilik_rekening" value="{{ old('nama_pemilik_rekening') }}" required
               style="width:100%; padding:10px 12px; border:1px solid #F3B4B4; border-radius:4px; margin-bottom:16px; box-sizing:border-box; font-family:Arial, sans-serif;">

        <div style="background:#FCE9C7; color:#8A5A00; border-radius:4px; padding:12px 16px; margin-bottom:20px; font-size:13px;">
            Pengajuan akan diteruskan ke Bendahara untuk diproses dan dicairkan sesuai metode di atas.
        </div>

        <div style="display:flex; gap:8px;">
            <button type="submit" style="padding:12px 28px; background:#B91C1C; color:#ffffff; border:none; border-radius:4px; font-weight:bold; cursor:pointer;">Ajukan</button>
            <a href="{{ route('simpanan.setor') }}" style="padding:12px 28px; background:#ffffff; color:#241412; border:1px solid #F3B4B4; border-radius:4px; font-weight:bold; text-decoration:none;">Batal</a>
        </div>
    </form>

    <script>
        const metodeSelect = document.getElementById('metode_penarikan');
        const rekeningArea = document.getElementById('rekeningArea');
        const jumlahDisplayTarik = document.getElementById('jumlah_display');
const jumlahHiddenTarik = document.getElementById('jumlah');
const jumlahErrorTarik = document.getElementById('jumlah_error');
const saldoSukarelaTersedia = {{ $saldoSukarela }};

const MIN_TARIK = 50000;

function formatRibuanTarik(v) {
    return v.replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

jumlahDisplayTarik.addEventListener('input', function () {
    const angka = this.value.replace(/\D/g, '');
    this.value = angka ? 'Rp ' + formatRibuanTarik(angka) : '';
    jumlahHiddenTarik.value = angka;
});

document.getElementById('formTarik').addEventListener('submit', function (e) {
    const angka = parseInt(jumlahHiddenTarik.value || '0', 10);

    if (!angka || angka < MIN_TARIK) {
        e.preventDefault();
        jumlahErrorTarik.textContent = 'Jumlah penarikan minimal Rp ' + formatRibuanTarik(String(MIN_TARIK)) + '.';
        jumlahErrorTarik.style.display = 'block';
        jumlahDisplayTarik.focus();
    } else if (angka > saldoSukarelaTersedia) {
        e.preventDefault();
        jumlahErrorTarik.textContent = 'Jumlah penarikan melebihi saldo simpanan sukarela yang tersedia.';
        jumlahErrorTarik.style.display = 'block';
        jumlahDisplayTarik.focus();
    } else {
        jumlahErrorTarik.style.display = 'none';
    }
});
        function toggleRekening() {
            rekeningArea.style.display = metodeSelect.value === 'Tunai' ? 'none' : 'block';
        }
        metodeSelect.addEventListener('change', toggleRekening);
        toggleRekening();
    </script>

</x-anggota-layout>
